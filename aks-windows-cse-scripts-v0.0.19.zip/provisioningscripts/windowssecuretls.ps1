﻿#***************************************************************************************************************
# It does the following:
#   *   Disable TLS 1.O, TLS 1.1, SSLv2, SSLv3 and enables TLS1.2
#   *   The CipherSuite order is set to the SDL approved version.
#   *   The FIPS MinEncryptionLevel is set to 3.
#   *   RC4 is disabled
#***************************************************************************************************************

#******************* FUNCTION THAT ACTUALLY UPDATES KEYS ***********************
function Set-CryptoSetting {
    param ( 
        $regKeyName, 
        $value, 
        $valuedata, 
        $valuetype      
    ) 

    # Check for existence of registry key, and create if it does not exist 
    If (!(Test-Path -Path $regKeyName)) { 
        New-Item $regKeyName | Out-Null 
    } 

    # Get data of registry value, or null if it does not exist 
    $val = (Get-ItemProperty -Path $regKeyName -Name $value -ErrorAction SilentlyContinue).$value 


    If ($val -eq $null) { 
        # Value does not exist - create and set to desired value 
        New-ItemProperty -Path $regKeyName -Name $value -Value $valuedata -PropertyType $valuetype | Out-Null 
    }
    Else { 
        # Value does exist - if not equal to desired value, change it 
        If ($val -ne $valuedata) { 
            Set-ItemProperty -Path $regKeyName -Name $value -Value $valuedata 
        } 
    } 
}
#***************************************************************************************************************

#******************* FUNCTION THAT DISABLES RC4 ***********************
function DisableRC4 {
    $subkeys = Get-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL" 
    $ciphers = $subkeys.OpenSubKey("Ciphers", $true) 

    Write-Log "----- Checking the status of RC4 -----"

    $RC4 = $false
    if ($ciphers.SubKeyCount -eq 0) { 
        $k1 = $ciphers.CreateSubKey("RC4 128/128") 
        $k1.SetValue("Enabled", 0, [Microsoft.Win32.RegistryValueKind]::DWord) 
        $k2 = $ciphers.CreateSubKey("RC4 64/128") 
        $k2.SetValue("Enabled", 0, [Microsoft.Win32.RegistryValueKind]::DWord) 
        $k3 = $ciphers.CreateSubKey("RC4 56/128") 
        $k3.SetValue("Enabled", 0, [Microsoft.Win32.RegistryValueKind]::DWord) 
        $k4 = $ciphers.CreateSubKey("RC4 40/128") 
        $k4.SetValue("Enabled", 0, [Microsoft.Win32.RegistryValueKind]::DWord) 
        
        Write-Log "RC4 was disabled "
        $RC4 = $true
    } 

    If ($RC4 -ne $true) {
        Write-Log "There was no change for RC4 "
    }
}
#***************************************************************************************************************

#******************* FUNCTION CHECKS FOR PROBLEMATIC FIPS SETTING AND FIXES IT  ***********************
function Test-RegistryValueForFipsSettings {            
    $fipsPath = @( 
        "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp",
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services",
        "HKLM:\System\CurrentControlSet\Control\Terminal Server\DefaultUserConfiguration"
    )
    
    $fipsValue = "MinEncryptionLevel"
    
    foreach ($path in $fipsPath) {
        Write-Log "Checking to see if $($path)\$fipsValue exists"

        $ErrorActionPreference = "stop"
        Try {
            $result = Get-ItemProperty -Path $path | Select-Object -ExpandProperty $fipsValue
            if ($result -eq 4) {
                set-itemproperty -Path $path -Name $fipsValue -value 3
                Write-Log "Regkey $($path)\$fipsValue was changed from value $result to a value of 3"
            }
            else {
                Write-Log "Regkey $($path)\$fipsValue left at value $result"
            }
    
        }
        Catch [System.Management.Automation.ItemNotFoundException] {
            Write-Log "Reg path $path was not found"
        }
        Catch [System.Management.Automation.PSArgumentException] {
            Write-Log "Regkey $($path)\$fipsValue was not found"
        }
        Catch {
            Write-Log "Error of type $($Error[0].Exception.GetType().FullName) trying to get $($path)\$fipsValue"
        }
        Finally {
            $ErrorActionPreference = "Continue"
        }
    }
}
#***************************************************************************************************************

#********************************TLS CipherSuite Settings *******************************************

# CipherSuites for windows OS < 10
function Get-BaseCipherSuitesOlderWindows()
{
    param
    (
        [Parameter(Mandatory=$true, Position=0)][bool] $isExcellenceOrder
    )
    $cipherorder = @()

    if ($isExcellenceOrder -eq $true)
    {
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P384"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P384"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P384"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P256"
    }
    else
    {
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P384"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P384"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P384"
    }

    # Add additional ciphers when EnableOlderTlsVersions flag is set to true
    if ($EnableOlderTlsVersions)
    {
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256"
        $cipherorder += "TLS_RSA_WITH_AES_256_GCM_SHA384" 
        $cipherorder += "TLS_RSA_WITH_AES_128_GCM_SHA256" 
        $cipherorder += "TLS_RSA_WITH_AES_256_CBC_SHA256" 
        $cipherorder += "TLS_RSA_WITH_AES_128_CBC_SHA256" 
        $cipherorder += "TLS_RSA_WITH_AES_256_CBC_SHA"
        $cipherorder += "TLS_RSA_WITH_AES_128_CBC_SHA"
    }
    return $cipherorder
}

# Ciphersuites needed for backwards compatibility with Firefox, Chrome
# Server 2012 R2 doesn't support TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384
# Both firefox and chrome negotiate ECDHE_RSA_AES_256_CBC_SHA1, Edge negotiates ECDHE_RSA_AES_256_CBC_SHA384
function Get-BrowserCompatCipherSuitesOlderWindows()
{
    param
    (
        [Parameter(Mandatory=$true, Position=0)][bool] $isExcellenceOrder
    )
    $cipherorder = @()

    if ($isExcellenceOrder -eq $true)
    {
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P384"  # (uses SHA-1)  
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256"  # (uses SHA-1)
    }
    else
    {
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256"  # (uses SHA-1)
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P384"  # (uses SHA-1)  
    }
    return $cipherorder
}

# Ciphersuites for OS versions windows 10 and above
function Get-BaseCipherSuitesWin10Above()
{
    param
    (
        [Parameter(Mandatory=$true, Position=0)][bool] $isExcellenceOrder
    )

    $cipherorder = @()
    if ($isExcellenceOrder -eq $true)
    {
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"
    }
    else
    {
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384"
    }
    # Add additional ciphers when EnableOlderTlsVersions flag is set to true
    if ($EnableOlderTlsVersions)
    {
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256"
        $cipherorder += "TLS_RSA_WITH_AES_256_GCM_SHA384" 
        $cipherorder += "TLS_RSA_WITH_AES_128_GCM_SHA256" 
        $cipherorder += "TLS_RSA_WITH_AES_256_CBC_SHA256" 
        $cipherorder += "TLS_RSA_WITH_AES_128_CBC_SHA256" 
        $cipherorder += "TLS_RSA_WITH_AES_256_CBC_SHA"
        $cipherorder += "TLS_RSA_WITH_AES_128_CBC_SHA"
    }

    return $cipherorder
}

#******************************* TLS Version Settings ****************************************************

function Get-RegKeyPathForTls12()
{
    $regKeyPath = @(
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2",        
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client", 
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server" 
    )
    return $regKeyPath
}

function Get-RegKeyPathForTls11()
{
    $regKeyPath = @(
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1", 
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client",
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server" 
    )
    return $regKeyPath
}

function Get-RegKeypathForTls10()
{
    $regKeyPath = @(
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0", 
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client", 
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server"
    )
    return $regKeyPath
}

function Get-RegKeyPathForSsl30()
{
    $regKeyPath = @(
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0",        
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client", 
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server"
    )
    return $regKeyPath
}

function Get-RegKeyPathForSsl20()
{
    $regKeyPath = @(
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0",
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client",  
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server"
    )
    return $regKeyPath
}

#******************************* Wrap TLSSettings.ps1 to a function without restart **********************

function Enable-SecureTls {
    $registryPathGoodGuys = @()
    $registryPathBadGuys = @()

    Write-Log -Message "========== Start of logging for Enable-SecureTls =========="
    # we enable TLS 1.2 and disable others
    $registryPathGoodGuys += Get-RegKeyPathForTls12

    $registryPathBadGuys += Get-RegKeyPathForSsl20
    $registryPathBadGuys += Get-RegKeyPathForSsl30
    $registryPathBadGuys += Get-RegKeypathForTls10
    $registryPathBadGuys += Get-RegKeyPathForTls11
    Write-Log "Enabling TLS1.2. Disabling TLS1.1, TLS1.0, SSL3.0, SSL2.0"

    Write-Log "Check which registry keys exist already and which registry keys need to be created." 

    #******************* CREATE THE REGISTRY KEYS IF THEY DON'T EXIST********************************
    # Check for existence of GoodGuy registry keys, and create if they do not exist 
    For ($i = 0; $i -lt $registryPathGoodGuys.Length; $i = $i + 1) { 
        Write-Log "Checking for existing of key: $($registryPathGoodGuys[$i]) "
        If (!(Test-Path -Path $registryPathGoodGuys[$i])) { 
            New-Item $registryPathGoodGuys[$i] | Out-Null
            Write-Log "Creating key: $($registryPathGoodGuys[$i]) "
        }
    } 
    
    # Check for existence of BadGuy registry keys, and create if they do not exist 
    For ($i = 0; $i -lt $registryPathBadGuys.Length; $i = $i + 1) { 
        Write-Log "Checking for existing of key: $($registryPathBadGuys[$i]) "
        If (!(Test-Path -Path $registryPathBadGuys[$i])) { 
            Write-Log "Creating key: $($registryPathBadGuys[$i]) "
            New-Item  $registryPathBadGuys[$i] | Out-Null
        }
    }

    #******************* EXPLICITLY DISABLE SSLV2, SSLV3, TLS10 AND TLS11 ********************************
    For ($i = 0; $i -lt $registryPathBadGuys.Length; $i = $i + 1) {
        if ($registryPathBadGuys[$i].Contains("Client") -Or $registryPathBadGuys[$i].Contains("Server")) {
            Write-Log "Disabling this key: $($registryPathBadGuys[$i]) "
            Set-CryptoSetting $registryPathBadGuys[$i].ToString() Enabled 0 DWord  
            Set-CryptoSetting $registryPathBadGuys[$i].ToString() DisabledByDefault 1 DWord  
        }
    }

    #********************************* EXPLICITLY Enable TLS12 ****************************************
    For ($i = 0; $i -lt $registryPathGoodGuys.Length; $i = $i + 1) {
        if ($registryPathGoodGuys[$i].Contains("Client") -Or $registryPathGoodGuys[$i].Contains("Server")) {
            Write-Log "Enabling this key: $($registryPathGoodGuys[$i]) " 
            Set-CryptoSetting $registryPathGoodGuys[$i].ToString() Enabled 1 DWord  
            Set-CryptoSetting $registryPathGoodGuys[$i].ToString() DisabledByDefault 0 DWord 
        }
    }

    #************************************** Disable RC4 ************************************************
    DisableRC4
        
    #************************************** Set Cipher Suite Order **************************************
    Write-Log "----- starting ciphersuite order calculation for excellence cipher suite order -----" 
    $cipherlist = @()

    if ([Environment]::OSVersion.Version.Major -lt 10) 
    {
        $cipherlist += Get-BaseCipherSuitesOlderWindows -isExcellenceOrder $true
        $cipherlist += Get-BrowserCompatCipherSuitesOlderWindows -isExcellenceOrder $true
    }
    else
    {
        $cipherlist += Get-BaseCipherSuitesWin10Above -isExcellenceOrder $true
    }
    $cipherorder = [System.String]::Join(",", $cipherlist)
    Write-Log "Appropriate ciphersuite order : $cipherorder"
    
    $CipherSuiteRegKey = "HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002" 
    
    if (!(Test-Path -Path $CipherSuiteRegKey)) 
    { 
        New-Item $CipherSuiteRegKey | Out-Null 
        Write-Log "Creating key: $($CipherSuiteRegKey) "
    } 
    
    $val = (Get-Item -Path $CipherSuiteRegKey -ErrorAction SilentlyContinue).GetValue("Functions", $null)
    Write-Log "Previous cipher suite value: $val  "
    Write-Log "New cipher suite value     : $cipherorder  "		 
        
    if ($val -ne $cipherorder) 
    { 
        Write-Log "Cipher suite order needs to be updated. "
        Set-ItemProperty -Path $CipherSuiteRegKey -Name Functions -Value $cipherorder 
        Write-Log "Cipher suite value was updated. "
    }
    else
    {
        Write-Log "Cipher suite order does not need to be updated. "
        Write-Log "Cipher suite value was not updated as there was no change. "
    }
            
    #****************************** CHECK THE FIPS SETTING WHICH IMPACTS RDP'S ALLOWED CIPHERS **************************
    #Check for FipsSettings
    Write-Log "Checking to see if reg keys exist and if MinEncryptionLevel is set to 4"
    Test-RegistryValueForFipsSettings

    Write-Log -Message "========== End of logging for Enable-SecureTls =========="
}
# SIG # Begin signature block
# MIIntgYJKoZIhvcNAQcCoIInpzCCJ6MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC4Cg6bwG/kK8UL
# itAPozfwsX0+Un/Nahpl3yHditLdbKCCDZYwggYUMIID/KADAgECAhMzAAAC8wlu
# RQfXwCSWAAAAAALzMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNjMwMTczODIyWhcNMjMwOTE1MTczODIyWjCBiDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWlj
# cm9zb2Z0IDNyZCBQYXJ0eSBBcHBsaWNhdGlvbiBDb21wb25lbnQwggEiMA0GCSqG
# SIb3DQEBAQUAA4IBDwAwggEKAoIBAQCvrQmB9lUe3LFSMM9FTJgENkeA6ehq7Ywo
# CbAga/IYYTpKOyDPJkY9lJOzTPHaIq0XIz4wwAZpM+ECf5Lxb4s79ue7Q+Fg1N/H
# TeAwEDOrSq9jbJTfKxd8f4Lnep+9b91TNh1PvXSpdRVAju+k5VTt75ooadqooEPJ
# /xnS6r1wdcdpeTvh6byyOoNSSbZ4MlBlaJzkM0SeTDw4GNB60KQu1ZUe18H4nRPI
# l7hsoNzBoHqMjbOJbFIf/cdIWlMidscq0Ze6JtCgl8D6Y8tigVEYk3x/ulPfSDm2
# 4s1QrhBSyx6dlOd5AD+mexUWZ+ghqADDDFGGuQY+1WQ7CoKrF33XAgMBAAGjggF+
# MIIBejAfBgNVHSUEGDAWBgorBgEEAYI3TBEBBggrBgEFBQcDAzAdBgNVHQ4EFgQU
# enNHb1tirNTTqab7EgNbT9ptw+AwUAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzE1MjIr
# NDcxMzM2MB8GA1UdIwQYMBaAFEhuZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRN
# MEswSaBHoEWGQ2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01p
# Y0NvZFNpZ1BDQTIwMTFfMjAxMS0wNy0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEG
# CCsGAQUFBzAChkVodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRz
# L01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADAN
# BgkqhkiG9w0BAQsFAAOCAgEAgIkmgihpTZGRMo1zyVuwhFlLzWEDBPxevB+sjcgH
# tISRCEBxwcBKS6WPYPkJCd+cDo3bEMdfCPgyMfBMxQ2DlXaSnRGc5wPVC6hazl55
# S4c6AxacmukRbVe89sb+pbrjxaYJe5Umr4tc9+7ad/e28yirdprT/38KRKXeVwjV
# ZRAUrqyf9SRpOhtD2rcNZRciL82Ib9db3bzzoaG9y0kCaQ+OljehQ8ZOO4Quv8Ze
# 3JGet7zn0KLmXkXSbgaNRiZLneQdB6vL2GW3LrCyVad0Aph9c4SyvlW0FuaMUCRQ
# UL7UcVVT6gUJIIyHHKJ1XGcgdbmAFxA9lDrgogbmc6TUzBUfAWGsgeoAzNTJZ7aO
# Zzg0Y3Y21hsBKAp1Gxz0oys3GB5s7t6msK72zzRsLZF75t8ktuokrkd8C5IS2p/6
# hF0LtPl3aWP0k1V+CYPZw0CgHHVeX5fC/1V353HR8o/T106F636/G4YvMpqm3JTo
# AFAuaGhU5aepW83ZRRjCnZkzUCYCOiDcoDdjcrr6Iu2h54Owqb44JNUnlmCeXNyf
# aPCfpvI9G3PgHg3SyXI67A532uhlNTWXnVaubMjuaKaAlReGQTxeXAOcuzQ71PQX
# cv87lHPdgGJAXxymnSaBWVVXp86Y20fRedFskTYV4YwcRsNk4HwwqdnHy/JWhhn7
# SJUwggd6MIIFYqADAgECAgphDpDSAAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNy
# b3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgy
# MDU5MDlaFw0yNjA3MDgyMTA5MDlaMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENB
# IDIwMTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhu
# qoIQTTS68rZYIZ9CGypr6VpQqrgGOBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEU
# MULTiQ15ZId+lGAkbK+eSZzpaF7S35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugy
# UiYSL+erCFDPs0S3XdjELgN1q2jzy23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4
# 494HDdVceaVJKecNvqATd76UPe/74ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7
# hhvZPrGMXeiJT4Qa8qEvWeSQOy2uM1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1
# JcM5bmR/U7qcD60ZI4TL9LoDho33X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbP
# fLGSrhwjp6lm7GEfauEoSZ1fiOIlXdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez
# +ADhvKwCgl/bwBWzvRvUVUvnOaEP6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX
# 24ON7E1JMKerjt/sW5+v/N2wZuLBl4F77dbtS+dJKacTKKanfWeA5opieF+yL4TX
# V5xcv3coKPHtbcMojyyPQDdPweGFRInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8z
# hNqwiBfenk70lrC8RqBsmNLg1oiMCwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUB
# BAMCAQAwHQYDVR0OBBYEFEhuZOVQBdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcU
# AgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8G
# A1UdIwQYMBaAFHItOgIxkEO5FAVO4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuG
# SWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jv
# b0NlckF1dDIwMTFfMjAxMV8wM18yMi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsG
# AQUFBzAChkJodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dDIwMTFfMjAxMV8wM18yMi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYB
# BAGCNy4DMIGDMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL2RvY3MvcHJpbWFyeWNwcy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABl
# AGcAYQBsAF8AcABvAGwAaQBjAHkAXwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJ
# KoZIhvcNAQELBQADggIBAGfyhqWY4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFl
# Xy4sPvjDctFtg/6+P+gKyju/R6mj82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzz
# PEKLUtCw/WvjPgcuKZvmPRul1LUdd5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirC
# ihC7pKkFDJvtaPpoLpWgKj8qa1hJYx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7l
# ryft0N3zDq+ZKJeYTQ49C/IIidYfwzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhR
# RVg4MnEnGn+x9Cf43iw6IGmYslmJaG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGP
# fxxvFX1Fp3blQCplo8NdUmKGwx1jNpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+
# BncG0QaxdR8UvmFhtfDcxhsEvt9Bxw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQ
# mYAf0AApxbGbpT9Fdx41xtKiop96eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3
# mXkYS//WsyNodeav+vyL6wuA6mk7r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEy
# IXrvQQqxP/uozKRdwaGIm1dxVk5IRcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDN
# MYIZdjCCGXICAQEwgZUwfjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEoMCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQIT
# MwAAAvMJbkUH18AklgAAAAAC8zANBglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0B
# CQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAv
# BgkqhkiG9w0BCQQxIgQgj8oSo2FiK+wbkWIcoSTgKbldU1G1atiJbCfph99vFSAw
# QgYKKwYBBAGCNwIBDDE0MDKgFIASAE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQAGHIbubgnE9Cd+
# 0Yy/KxiWcmF/NOEGYpTsqHnk6rtbY4ZRdsDM4SuG0d2YzJy97otmPgl6UJIslGiV
# XJ7s2LDews526mi3m+4fMJxpNSHdZ54c4tgwC/bmit9lLgLWSN4NJx5ZIEn5wXjI
# s4Ks1Qdc511kdictciZLuv04NEkkdbKZ6mHrazK/T0uS951xAdqUnIf+USQ1wOx/
# +HVfj6dfhJrvG1Kgr8US029NlgEHSSAjmxlRigyy4NEIP32NdOUcjVGwzv3Rr8dC
# M5sdhk6LlPRq8Wf5T8kBS12y76ut6wRZCz0LfQYMeIwpg/+t3RvR6wq8ChDirePb
# ID5hcbU2oYIXADCCFvwGCisGAQQBgjcDAwExghbsMIIW6AYJKoZIhvcNAQcCoIIW
# 2TCCFtUCAQMxDzANBglghkgBZQMEAgEFADCCAVEGCyqGSIb3DQEJEAEEoIIBQASC
# ATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIJc3JlefjlX3
# g1OlhJeEzPEQ9WL1A2AXlM/d6hInYvdeAgZjI0r9XKYYEzIwMjIwOTI2MDMwNjIz
# LjAzNlowBIACAfSggdCkgc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkU1QTYtRTI3Qy01OTJFMSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIRVzCCBwwwggT0oAMCAQIC
# EzMAAAGVt/wN1uM3MSUAAQAAAZUwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwHhcNMjExMjAyMTkwNTEyWhcNMjMwMjI4MTkwNTEy
# WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UE
# CxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVz
# IFRTUyBFU046RTVBNi1FMjdDLTU5MkUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1l
# LVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCf
# bUEMZ7ZLOz9aoRCeJL4hhT9Q8JZB2xaVlMNCt3bwhcTI5GLPrt2e93DAsmlqOzw1
# cFiPPg6S5sLCXz7LbbUQpLha8S4v2qccMtTokEaDQS+QJErnAsl6VSmRvAy0nlj+
# C/PaZuLb3OzY0ARw7UeCZLpyWPPH+k5MdYj6NUDTNoXqbzQHCuPs+fgIoro5y3DH
# oO077g6Ir2THIx1yfVFEt5zDcFPOYMg4yBi4A6Xc3hm9tZ6w849nBvVKwm5YALfH
# 3y/f3n4LnN61b1wzAx3ZCZjf13UKbpE7p6DYJrHRB/+pwFjG99TwHH6uXzDeZT6/
# r6qH7AABwn8fpYc1TmleFY8YRuVzzjp9VkPHV8VzvzLL7QK2kteeXLL/Y4lvjL6h
# zyOmE+1LVD3lEbYho1zCt+F7bU+FpjyBfTC4i/wHsptb218YlbkQt1i1B6llmJwV
# FwCLX7gxQ48QIGUacMy8kp1+zczY+SxlpaEgNmQkfc1raPh9y5sMa6X48+x0K7B8
# OqDoXcTiECIjJetxwtuBlQseJ05HRfisfgFm09kG7vdHEo3NbUuMMBFikc4boN9U
# fm0iUhq/JtqV0Kwrv9Cv3ayDgdNwEWiL2a65InEWSpRTYfsCQ03eqEh5A3rwV/Kf
# UFcit+DrP+9VcDpjWRsCokZv4tgn5qAXNMtHa8NiqQIDAQABo4IBNjCCATIwHQYD
# VR0OBBYEFKuX02ICFFdXgrcCBmDJfH5v/KkXMB8GA1UdIwQYMBaAFJ+nFV0AXmJd
# g/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGlt
# ZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0l
# BAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggIBAOCzNt4fJ+jOvQuq0Itn
# 37IZrYNBGswAi+IAFM3YGK/wGQlEncgjmNBuac95W2fAL6xtFVfMfkeqSLMLqoid
# VsU9Bm4DEBjaWNOT9uX/tcYiJSfFQM0rDbrl8V4nM88RZF56G/qJW9g5dIqOSoim
# zKUt/Q7WH6VByW0sar5wGvgovK3qFadwKShzRYcEqTkHH2zip5e73jezPHx2+taY
# qJG5xJzdDErZ1nMixRjaHs3KpcsmZYuxsIRfBYOJvAFGymTGRv5PuwsNps9Ech1A
# asq84H/Y/8xN3GQj4P3MiDn8izUBDCuXIfHYk39bqnaAmFbUiCby+WWpuzdk4oDK
# z/sWwrnsoQ72uEGVEN7+kyw9+HSo5i8l8Zg1Ymj9tUgDpVUGjAduoLyHQ7XqknKm
# S9kJSBKk4okEDg0Id6LeKLQwH1e4aVeTyUYwcBX3wg7pLJQWvR7na2SGrtl/23YG
# QTudmWOryhx9lnU7KBGV/aNvz0tTpcsucsK+cZFKDEkWB/oUFVrtyun6ND5pYZNj
# 0CgRup5grVACq/Agb+EOGLCD+zEtGNop4tfKvsYb64257NJ9XrMHgpCib76WT34R
# PmCBByxLUkHxHq5zCyYNu0IFXAt1AVicw14M+czLYIVM7NOyVpFdcB1B9MiJik7p
# eSii0XTRdl5/V/KscTaCBFz3MIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAA
# AAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUg
# QXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQAD
# ggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2
# AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpS
# g0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2r
# rPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k
# 45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSu
# eik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09
# /SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR
# 6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxC
# aC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaD
# IV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMUR
# HXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMB
# AAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQq
# p1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ
# 6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRt
# MBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBB
# MAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP
# 6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWlj
# cm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2
# LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2
# Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03d
# mLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1Tk
# eFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kp
# icO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKp
# W99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrY
# UP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QB
# jloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkB
# RH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0V
# iY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq
# 0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1V
# M1izoXBm8qGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBP
# cGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpFNUE2LUUyN0MtNTky
# RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcG
# BSsOAwIaAxUA0Y+CyLezGgVHWFNmKI1LuE/hY6uggYMwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOba+AYwIhgPMjAy
# MjA5MjUyMzUzNDJaGA8yMDIyMDkyNjIzNTM0MlowdzA9BgorBgEEAYRZCgQBMS8w
# LTAKAgUA5tr4BgIBADAKAgEAAgIStAIB/zAHAgEAAgIR1jAKAgUA5txJhgIBADA2
# BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIB
# AAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAK8Yet5y8FXZ+YrV4WT/wg2Ii4z9aK0r
# YZGPo2f+AppahB5dvhaHiBqYYo9+jk8NYGzXAi384L9PD+cuyEF7E8XBV71txvTW
# fO0Zela51XnOfSBKJCkW9z3INbNPM1IXHgfl/0U9Y4AoVcmp09MD6Fcm45EpqXEs
# bqB5/hV8MTD2MYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAGVt/wN1uM3MSUAAQAAAZUwDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgvldheMag
# befA4hZAAg7RCY50pKJOyIk7Mm5N7700P40wgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCBc5kvhjZALe2mhIz/Qd7keVOmA/cC1dzKZT4ybLEkCxzCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABlbf8DdbjNzElAAEA
# AAGVMCIEICy2V+JknuNMqzKwNOClDCe0UgIxtAEmgVSssJRXDpHTMA0GCSqGSIb3
# DQEBCwUABIICAJpaXCT32xEpaL7InFHjLAFkSWl2DTpoeZpEc0TkMKwnNeX9YFvs
# /06TjyZLIugfGIY3lVgfiNtw11q72luHun5AtH7cT7sUZpypE8jkQDbGA9e8iLXa
# yMnNDC/DUZo4VRQuQuecoAPof76///TX33pCxKAiKcPPzcdMqRdXyfVgwVJZCv3s
# qzvJYnjX1IiB9QGzNyA3sjeozZ0C4z5VUagcEyK9iFptoshaLjtFjknnRUDSVwSS
# l2K9qHp/JDsfQxWKSzL9KoT7A488tAKEZ6F0DA8V0hSwRUiw+HkoVEVGXDu0+Ywb
# LJyjr7bPSqwQLqjXS6E4f38nZcX61QFOwHMU707N3OTQ0BuU83fOxIyya6XuxPjo
# Vx6UleKC8lV/TZfacCPY2Fl7ZlpruCkBmDmA4wqqSKK3us53TckxmBDtfeZeiUnS
# kpGn5fDA6nXYGvp1HxtuxIG/0rMd1JMUZ7n02IT396Sy+QbW/lvimpoEpLMiKlkT
# Cm7zhgZSB0x2GZLHJEl1stUXEViGHbKTfzwqrDKVHbbS55cAoA5QBWePooWdvwPr
# IS1tPwJA34+2r4zHheYqDg00aVOfs3GqmPOBVhzSLNA1Q0QP+X0lXoSzcbSa86fZ
# SAOPOsiKsGLEkvAIhApnBdndSpSL8tRVLklAkAWcXBTAx3JP6KT3C9dg
# SIG # End signature block
