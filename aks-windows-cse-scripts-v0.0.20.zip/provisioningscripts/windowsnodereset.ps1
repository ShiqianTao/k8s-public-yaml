<#
.DESCRIPTION
    This script is intended to be run each time a windows nodes is restarted and performs
    cleanup actions to help ensure the node comes up cleanly.
#>

$global:LogPath = "c:\k\windowsnodereset.log"

$Global:ClusterConfiguration = ConvertFrom-Json ((Get-Content "c:\k\kubeclusterconfig.json" -ErrorAction Stop) | out-string)

$global:HNSRemediatorIntervalInMinutes = [System.Convert]::ToUInt32($Global:ClusterConfiguration.Services.HNSRemediator.IntervalInMinutes)
$global:CsiProxyEnabled = [System.Convert]::ToBoolean($Global:ClusterConfiguration.Csi.EnableProxy)
$global:MasterSubnet = $Global:ClusterConfiguration.Kubernetes.ControlPlane.MasterSubnet
$global:NetworkMode = "L2Bridge"
$global:NetworkPlugin = $Global:ClusterConfiguration.Cni.Name
$global:ContainerRuntime = $Global:ClusterConfiguration.Cri.Name
$UseContainerD = ($global:ContainerRuntime -eq "containerd")
$IsDualStackEnabled = $Global:ClusterConfiguration.Kubernetes.Kubeproxy.FeatureGates -contains "IPv6DualStack=true"

$global:HNSModule = "c:\k\hns.psm1"
if ($global:ContainerRuntime -eq "containerd") {
    Write-Host "ContainerRuntime is containerd. Use hns.v2.psm1"
    $global:HNSModule = "c:\k\hns.v2.psm1"
}

filter Timestamp { "$(Get-Date -Format o): $_" }

function Write-Log ($message) {
    $message | Timestamp | Tee-Object -FilePath $global:LogPath -Append
}

function Register-HNSRemediatorScriptTask {
    if ($global:HNSRemediatorIntervalInMinutes -ne 0) {
        Write-Log "Creating a scheduled task to run hnsremediator.ps1"

        $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-File `"c:\k\hnsremediator.ps1`""
        $principal = New-ScheduledTaskPrincipal -UserId SYSTEM -LogonType ServiceAccount -RunLevel Highest
        $trigger = New-JobTrigger -Once -At (Get-Date).Date -RepeatIndefinitely -RepetitionInterval (New-TimeSpan -Minutes $global:HNSRemediatorIntervalInMinutes)
        $definition = New-ScheduledTask -Action $action -Principal $principal -Trigger $trigger -Description "hns-remediator-task"
        Register-ScheduledTask -TaskName "hns-remediator-task" -InputObject $definition
    }
}

function Unregister-HNSRemediatorScriptTask {
    # We do not check whether $global:HNSRemediatorIntervalInMinutes is not 0 sicne we may need to set it to 0 in the node for test purpose
    if (Get-ScheduledTask -TaskName "hns-remediator-task" -ErrorAction Ignore) {
        Write-Log "Deleting the scheduled task hns-remediator-task"
        Unregister-ScheduledTask -TaskName "hns-remediator-task" -Confirm:$false
    }

    $hnsPIDFile="C:\k\hns.pid"
    if (Test-Path $hnsPIDFile) {
        # Remove this file since PID of HNS service may have been changed after node crashes or is rebooted
        # It should not always fail since hns-remediator-task is unregistered.
        # We set the max retry count to 20 to avoid dead loop for unknown issues.
        $maxRetries=20
        $retryCount=0
        while ($retryCount -lt $maxRetries) {
            Write-Log "Deleting $hnsPIDFile"
            Remove-Item -Path $hnsPIDFile -Force -Confirm:$false -ErrorAction Ignore

            # The file may not be deleted successfully because hnsremediator.ps1 is still writing the logs
            if (Test-Path $hnsPIDFile) {
                # Do not log the failure to reduce log
                Start-Sleep -Milliseconds 500
                $retryCount=$retryCount+1
            } else {
                Write-Log "$hnsPIDFile is deleted"
                break
            }
        }
    }
}

Write-Log "Entering windowsnodereset.ps1"

Import-Module $global:HNSModule

Unregister-HNSRemediatorScriptTask

#
# Stop services
#
Write-Log "Stopping kubeproxy service"
Stop-Service kubeproxy

Write-Log "Stopping kubelet service"
Stop-Service kubelet

if ($global:CsiProxyEnabled) {
    Write-Log "Stopping csi-proxy service"
    Stop-Service csi-proxy
}

if ($global:EnableHostsConfigAgent) {
    Write-Log "Stopping hosts-config-agent service"
    Stop-Service hosts-config-agent
}

# Due to a bug in hns there is a race where it picks up the incorrect IPv6 address from the node in some cases.
# Hns service has to be restarted after the node internal IPv6 address is available when dual-stack is enabled.
# TODO Remove this once the bug is fixed in hns.
function Restart-HnsService {
    do {
        Start-Sleep -Seconds 1
        $nodeInternalIPv6Address = (Get-NetIPAddress | Where-Object {$_.PrefixOrigin -eq "Dhcp" -and $_.AddressFamily -eq "IPv6"}).IPAddress 
    } while ($nodeInternalIPv6Address -eq $null)
    Write-Log "Got node internal IPv6 address: $nodeInternalIPv6Address"
    
    $hnsManagementIPv6Address = (Get-HnsNetwork | Where-Object {$_.IPv6 -eq $true}).ManagementIPv6
    Write-Log "Got hns ManagementIPv6: $hnsManagementIPv6Address"

    if ($hnsManagementIPv6Address -ne $nodeInternalIPv6Address) {
        Restart-Service hns
        Write-Log "Restarted hns service"

        $hnsManagementIPv6Address = (Get-HnsNetwork | Where-Object {$_.IPv6 -eq $true}).ManagementIPv6
        Write-Log "Got hns ManagementIPv6: $hnsManagementIPv6Address after restart"
    }
    else {
        Write-Log "Hns network has correct IPv6 address, not restarting"
    }
}

if ($IsDualStackEnabled) {
    Restart-HnsService
}

#
# Perform cleanup
#

& "c:\k\cleanupnetwork.ps1"

#
# Create required networks
#

# If using kubenet create the HNS network here.
# (The kubelet creates the HNS network when using azure-cni + azure cloud provider)
if ($global:NetworkPlugin -eq 'kubenet') {
    Write-Log "Creating new hns network: $($global:NetworkMode.ToLower())"
    $podCIDR = Get-PodCIDR
    $masterSubnetGW = Get-DefaultGateway $global:MasterSubnet
    New-HNSNetwork -Type $global:NetworkMode -AddressPrefix $podCIDR -Gateway $masterSubnetGW -Name $global:NetworkMode.ToLower() -Verbose
    Start-sleep 10
}

#
# Start Services
#

if ($global:CsiProxyEnabled) {
    Write-Log "Starting csi-proxy service"
    Start-Service csi-proxy
}

Write-Log "Starting kubelet service"
Start-Service kubelet

Write-Log "Do not start kubeproxy service since kubelet will restart kubeproxy"

Register-HNSRemediatorScriptTask

Write-Log "Exiting windowsnodereset.ps1"

# SIG # Begin signature block
# MIInwgYJKoZIhvcNAQcCoIInszCCJ68CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCm8z4rGDcoYhJ+
# osfgR15wMYbcBmJRVsxOLk4XwrhN76CCDZYwggYUMIID/KADAgECAhMzAAAC8wlu
# RQfXwCSWAAAAAALzMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNjMwMTczODIyWhcNMjMwOTE1MTczODIyWjCBiDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWlj
# cm9zb2Z0IDNyZCBQYXJ0eSBBcHBsaWNhdGlvbiBDb21wb25lbnQwggEiMA0GCSqG
# SIb3DQEBAQUAA4IBDwAwggEKAoIBAQCvrQmB9lUe3LFSMM9FTJgENkeA6ehq7Ywo
# CbAga/IYYTpKOyDPJkY9lJOzTPHaIq0XIz4wwAZpM+ECf5Lxb4s79ue7Q+Fg1N/H
# TeAwEDOrSq9jbJTfKxd8f4Lnep+9b91TNh1PvXSpdRVAju+k5VTt75ooadqooEPJ
# /xnS6r1wdcdpeTvh6byyOoNSSbZ4MlBlaJzkM0SeTDw4GNB60KQu1ZUe18H4nRPI
# l7hsoNzBoHqMjbOJbFIf/cdIWlMidscq0Ze6JtCgl8D6Y8tigVEYk3x/ulPfSDm2
# 4s1QrhBSyx6dlOd5AD+mexUWZ+ghqADDDFGGuQY+1WQ7CoKrF33XAgMBAAGjggF+
# MIIBejAfBgNVHSUEGDAWBgorBgEEAYI3TBEBBggrBgEFBQcDAzAdBgNVHQ4EFgQU
# enNHb1tirNTTqab7EgNbT9ptw+AwUAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzE1MjIr
# NDcxMzM2MB8GA1UdIwQYMBaAFEhuZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRN
# MEswSaBHoEWGQ2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01p
# Y0NvZFNpZ1BDQTIwMTFfMjAxMS0wNy0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEG
# CCsGAQUFBzAChkVodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRz
# L01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADAN
# BgkqhkiG9w0BAQsFAAOCAgEAgIkmgihpTZGRMo1zyVuwhFlLzWEDBPxevB+sjcgH
# tISRCEBxwcBKS6WPYPkJCd+cDo3bEMdfCPgyMfBMxQ2DlXaSnRGc5wPVC6hazl55
# S4c6AxacmukRbVe89sb+pbrjxaYJe5Umr4tc9+7ad/e28yirdprT/38KRKXeVwjV
# ZRAUrqyf9SRpOhtD2rcNZRciL82Ib9db3bzzoaG9y0kCaQ+OljehQ8ZOO4Quv8Ze
# 3JGet7zn0KLmXkXSbgaNRiZLneQdB6vL2GW3LrCyVad0Aph9c4SyvlW0FuaMUCRQ
# UL7UcVVT6gUJIIyHHKJ1XGcgdbmAFxA9lDrgogbmc6TUzBUfAWGsgeoAzNTJZ7aO
# Zzg0Y3Y21hsBKAp1Gxz0oys3GB5s7t6msK72zzRsLZF75t8ktuokrkd8C5IS2p/6
# hF0LtPl3aWP0k1V+CYPZw0CgHHVeX5fC/1V353HR8o/T106F636/G4YvMpqm3JTo
# AFAuaGhU5aepW83ZRRjCnZkzUCYCOiDcoDdjcrr6Iu2h54Owqb44JNUnlmCeXNyf
# aPCfpvI9G3PgHg3SyXI67A532uhlNTWXnVaubMjuaKaAlReGQTxeXAOcuzQ71PQX
# cv87lHPdgGJAXxymnSaBWVVXp86Y20fRedFskTYV4YwcRsNk4HwwqdnHy/JWhhn7
# SJUwggd6MIIFYqADAgECAgphDpDSAAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNy
# b3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgy
# MDU5MDlaFw0yNjA3MDgyMTA5MDlaMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENB
# IDIwMTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhu
# qoIQTTS68rZYIZ9CGypr6VpQqrgGOBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEU
# MULTiQ15ZId+lGAkbK+eSZzpaF7S35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugy
# UiYSL+erCFDPs0S3XdjELgN1q2jzy23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4
# 494HDdVceaVJKecNvqATd76UPe/74ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7
# hhvZPrGMXeiJT4Qa8qEvWeSQOy2uM1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1
# JcM5bmR/U7qcD60ZI4TL9LoDho33X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbP
# fLGSrhwjp6lm7GEfauEoSZ1fiOIlXdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez
# +ADhvKwCgl/bwBWzvRvUVUvnOaEP6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX
# 24ON7E1JMKerjt/sW5+v/N2wZuLBl4F77dbtS+dJKacTKKanfWeA5opieF+yL4TX
# V5xcv3coKPHtbcMojyyPQDdPweGFRInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8z
# hNqwiBfenk70lrC8RqBsmNLg1oiMCwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUB
# BAMCAQAwHQYDVR0OBBYEFEhuZOVQBdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcU
# AgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8G
# A1UdIwQYMBaAFHItOgIxkEO5FAVO4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuG
# SWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jv
# b0NlckF1dDIwMTFfMjAxMV8wM18yMi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsG
# AQUFBzAChkJodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dDIwMTFfMjAxMV8wM18yMi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYB
# BAGCNy4DMIGDMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL2RvY3MvcHJpbWFyeWNwcy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABl
# AGcAYQBsAF8AcABvAGwAaQBjAHkAXwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJ
# KoZIhvcNAQELBQADggIBAGfyhqWY4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFl
# Xy4sPvjDctFtg/6+P+gKyju/R6mj82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzz
# PEKLUtCw/WvjPgcuKZvmPRul1LUdd5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirC
# ihC7pKkFDJvtaPpoLpWgKj8qa1hJYx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7l
# ryft0N3zDq+ZKJeYTQ49C/IIidYfwzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhR
# RVg4MnEnGn+x9Cf43iw6IGmYslmJaG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGP
# fxxvFX1Fp3blQCplo8NdUmKGwx1jNpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+
# BncG0QaxdR8UvmFhtfDcxhsEvt9Bxw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQ
# mYAf0AApxbGbpT9Fdx41xtKiop96eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3
# mXkYS//WsyNodeav+vyL6wuA6mk7r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEy
# IXrvQQqxP/uozKRdwaGIm1dxVk5IRcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDN
# MYIZgjCCGX4CAQEwgZUwfjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEoMCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQIT
# MwAAAvMJbkUH18AklgAAAAAC8zANBglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0B
# CQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAv
# BgkqhkiG9w0BCQQxIgQgSZCyBgx2PLm9GYFP3xjZfcqkErppdK5FSSPtIZpL3Ygw
# QgYKKwYBBAGCNwIBDDE0MDKgFIASAE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQCr4Jdt6dJaEj0b
# Ff92OgUh3oJkAJLv57c7XU8hjbIF4SZc9JtAfiiTXK8JrWRAV/erF3/lslIPanbk
# SO2mKRqYZM1lRigxGTNfSeIye4FwUARzxgxFfGLNkQdUBY7yN+XSwFDxyij5eNmn
# y4h13WO4GfKMM9OWcxNuIEtN0L0EVCNcfBawcBb68/6xm8P20ySmF4gWLibJgDN5
# Q2cxurg7LUlIq/gQytxNqGfm9LMhSdTuZbowreGb1nQBp08xytNdNoxRwvdQ9e3N
# iW2KFZ6quVk571WPXYdLteKSOE1oa0WhhV2ZHNeNMvyL2xcHTP4Wbj0453A0vPHU
# hxnW8ekOoYIXDDCCFwgGCisGAQQBgjcDAwExghb4MIIW9AYJKoZIhvcNAQcCoIIW
# 5TCCFuECAQMxDzANBglghkgBZQMEAgEFADCCAVUGCyqGSIb3DQEJEAEEoIIBRASC
# AUAwggE8AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIHkncngIsH7c
# WoKGLfcFpe3/r8+NMxd+qMtEUSwKDYR2AgZjYr0/Uf8YEzIwMjIxMTA0MDUzNTI2
# LjQ4NVowBIACAfSggdSkgdEwgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBS
# aWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo2MEJDLUUzODMtMjYzNTElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCEV8wggcQMIIE+KAD
# AgECAhMzAAABpllFgzlNnutLAAEAAAGmMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIyMDMwMjE4NTEyMVoXDTIzMDUxMTE4
# NTEyMVowgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAn
# BgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQL
# Ex1UaGFsZXMgVFNTIEVTTjo2MEJDLUUzODMtMjYzNTElMCMGA1UEAxMcTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCC
# AgoCggIBANmYv3tSI+fJ/NQJnjz7JvCnc+Xm0rKoe9YKD4MvMYCul7egdrT/zv5v
# FbQgjNQ74672fNweaztkR65V8y29u5PL2sf01p+uche0Zu4tSig+GsQ6ZQl9tjPR
# AY/3ITBHDeIYyvq8Wne9+7NoPLhxDSO6dtX7YCuQ4zcTP3SE6MvB4b5NighdtvoZ
# VaYk1lXpjUTfdmKoX1ABq1sJbULSnSi0Qd4vvl3mZ9jxwv9dR/nlZP62lrZYZq7L
# PtHD6BlmclB5PT89DnSm1sjaZnFHrKzOsmq5GlmL5SFugCCZOoKz133FJeQaFMcX
# BZSCQjNABWBbHIRCE1ysHHG83DdonRmnC8EOlYeRwTWz/QCz6q0riOIbYyC/A2Bg
# UEpu9/9EymrTsyMr2/zS8GdEybQ5W7f0WrcrmKB/Y62+g6TmfOS8NtU+L1jGoKNG
# 6Q5RlfJwZu8J/Q9dl4OxyHKuy78+wm6HsF7uAizpsWh63UUaoK/OGQiBG3NJ+kef
# 5eWpnva4ZJfhAnqYTAZD1uHgf8VfQjnl0BB2YXzK9WaTqde8d+8qCxVKr5hJYvbO
# +X3+2k5PCirUK/SboreX+xUhVaQEhVDYqlatyPttI7Z2IrkhMzwFvc+p0QeyMiNm
# o2cBZejx8icDOcUidwymDUYqGPE7MA8vtKW3feeSSYJsCEkuUO/vAgMBAAGjggE2
# MIIBMjAdBgNVHQ4EFgQUOlQhO/zGlqK99UkNL/Gu/AryN9gwHwYDVR0jBBgwFoAU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIwVGltZS1TdGFt
# cCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBcBggrBgEFBQcw
# AoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNyb3Nv
# ZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIw
# ADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0BAQsFAAOCAgEAgMDxWDTp
# GqLnFoPhm/iDfwHGF8xr2NbrJl8egEg2ThTJsTf0wBE+ZQsnYfrRmXBbe6sCXLVN
# 70qPuI+OEbN5MOai7Bue1/4j5VTkWquH5GZeVat2N+dD7lSUWp0dU8j+uBhBL5GF
# SmoDVVm+zW2GR2juPI1v254AJTb2l458anlkJjGvmYn2BtRS13h/wDR7hrQaI7Bg
# dyHWAV5+HEj5UhrIrrvtwJiivSaUEA3qK6ZK/rZIQv/uORDkONw+2pHHIE1SXm/W
# IlhrVS2HIogfr3JjqvZion6LJSD741j8xVDLiClwAbspHoVFjxtxBcMjqPx6aWCJ
# S8vjSoTnhkV4PO55mqsM7Q8XQRGQhA7w4zNQOJu9kD4xFdYpPUmLN/daIcEElofB
# jGz+sEd1B4yqqIk3u2G4VygTXFmthL8chSo7r+GIvTqWKhSA/sanS4N3jCgCCe3F
# TSJsp4g5nwavLvWAtzcOIvSRorGmAeN0m2wgzBK95T/qgrGGDXSos1JNDWRVBnP0
# qsw1Qoq5G0D8hxvQPs3X43KBv1GJl0wo5rcC+9OMWxJlB63gtToQsA1CErYoYLMZ
# tUzJL74jwZk/grpHEQhIhB3sneC8wzGKJuft7YO/HWCpuwdChIjynTnBh+yFGMdg
# 3wRrIbOcw/iKmXZopMTQMOcmIeIwJAezA7AwggdxMIIFWaADAgECAhMzAAAAFcXn
# a54Cm0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0
# aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAx
# ODMyMjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9Kp
# bE51yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cy
# wBAY6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6
# xKr9cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bs
# hVZN7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZht
# aDuaRr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tn
# YN74kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+Autuqfjbs
# Nkz2K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNO
# wTM5TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28M
# yTZki1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsl
# uq9QBXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3
# PmriLq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGC
# NxUCBBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP0
# 5dJlpxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUF
# BwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3Np
# dG9yeS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBT
# AHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgw
# FoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0
# XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAx
# MC0wNi0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5y
# S/ypb+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi
# 7ulmZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2Rje
# bYIM9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n
# 4ECWOKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/
# LAl4FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Q
# q3UwxTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk
# 2XPXfx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBM
# drVXVAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/
# AsGConsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdC
# PSWU5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQ
# wXEGahC0HVUzWLOhcGbyoYIC0jCCAjsCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo2
# MEJDLUUzODMtMjYzNTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAanQzrZW9TB93Ve7Pa4UPao2ffK2ggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOcOjSYwIhgPMjAyMjExMDMyMjU1MzRaGA8yMDIyMTEwNDIyNTUzNFowdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA5w6NJgIBADAKAgEAAgIiUQIB/zAHAgEAAgIRIzAK
# AgUA5w/epgIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAGFMsuKo2++18COX
# P/DeZ4zySymm8SysEcMxQ+BHVKWjfds3w7WUlACdeWY5u7S+ZlEGS7FHL/U1L/Yh
# GLavCfw5kCKMATEe3psTLqTxqkl0gdvdz4/25/FAXEdI33QGM6dQpE9C7S/nF+De
# CAJBhIFfp1eK5xbWEaHxJ1SLtixrMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAGmWUWDOU2e60sAAQAAAaYwDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQgsJMPcnXaSJ7a8sZzjsN/5SQ92r6QbCdrYX21N1gXiMUwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCCDCxmLwz90fWvhMKbJTAQaKt3DoXeiAhfp8TD9
# tgSrDTCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# pllFgzlNnutLAAEAAAGmMCIEIG5n3M/0VSouCvQHVdfcoGHm01SHOnQkGoXRK2Bp
# Xv2kMA0GCSqGSIb3DQEBCwUABIICAM4p/cTJ9qwuZj9+ydn5lpJ8YgDm9HTUHtzG
# MBj9qO7Rpex3cPdgekApNusSZsFJBT/S4CEkSR6JalVjWSXGMXNAXEkeAAQYX03z
# 2+4xe4d/pevzMdWQaxr1OOf1CAVSZtDFnN/iMEZ8Di8yyFPM8jNdtkIb8/vOSrtB
# mvO+uwQNgAGCKu1MGMeqbF/DRmV8BPb4z8FlOm8PczFxYBXAUBDhW6oxzaMCY5X/
# 27eBTxsdua44FkHOcBShLC1SWqoFPsd6pWbL/nuakUbAODBa/4ntLP393e1FAOu+
# 8uO0FRW7HqRT93aJaBh599LB0LHY8PZV5wfFBkFTTDBFS6CAzjkfb8Ub8Z+ZF8Pg
# wxrCeBF5rn4gc4bdAs4mmM6oGT2OwwJfNOrEqBiKa0IHO0YxKkDWkNSBun3HDJlO
# Glenm5KDURFcKkrjKDGRFYrZikNzgvHnlHKKUUOunJFHI82VLVTJiDsjopghfciu
# RwdsxGC+9aIFwlskBVhWx2RH2Rztm3h7ezf/VM2gtmJ3PNufFy9v0jFh5n9wh1n+
# bXJwT63bv4Lhxjqe6rNAjmF6fhDf4h+OxBGtc+AlSwj4FW7ezmN1MJfMNOa1JCtk
# GkAPqPGLNXZBllNuB11Q3G9pcWgjj3YfIHBUxEC530Pz+FZLrtDI5iTzOADvfghs
# LswUEf4U
# SIG # End signature block
