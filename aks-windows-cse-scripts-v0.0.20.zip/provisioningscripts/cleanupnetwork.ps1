$Global:ClusterConfiguration = ConvertFrom-Json ((Get-Content "c:\k\kubeclusterconfig.json" -ErrorAction Stop) | out-string)

$global:NetworkMode = "L2Bridge"
$global:ContainerRuntime = $Global:ClusterConfiguration.Cri.Name
$global:NetworkPlugin = $Global:ClusterConfiguration.Cni.Name
$global:HNSModule = "c:\k\hns.psm1"
if ($global:ContainerRuntime -eq "containerd") {
    Write-Host "ContainerRuntime is containerd. Use hns.v2.psm1"
    $global:HNSModule = "c:\k\hns.v2.psm1"
}

ipmo $global:HNSModule

$networkname = $global:NetworkMode.ToLower()
if ($global:NetworkPlugin -eq "azure") {
    $networkname = "azure"
}

$hnsNetwork = Get-HnsNetwork | ? Name -EQ $networkname
if ($hnsNetwork) {
    # Cleanup all containers
    Write-Host "Cleaning up containers"
    if ($global:ContainerRuntime -eq "containerd") {
        ctr.exe -n k8s.io c ls -q | ForEach-Object { ctr -n k8s.io tasks kill $_ }
        ctr.exe -n k8s.io c ls -q | ForEach-Object { ctr -n k8s.io c rm $_ }
    }
    else {
        docker.exe ps -q | ForEach-Object { docker rm $_ -f }
    }
    
    Write-Host "Cleaning up persisted HNS policy lists"
    # Initially a workaround for https://github.com/kubernetes/kubernetes/pull/68923 in < 1.14,
    # and https://github.com/kubernetes/kubernetes/pull/78612 for <= 1.15
    #
    # October patch 10.0.17763.1554 introduced a breaking change 
    # which requires the hns policy list to be removed before network if it gets into a bad state
    # See https://github.com/Azure/aks-engine/pull/3956#issuecomment-720797433 for more info
    # Kubeproxy doesn't fail becuase errors are not handled: 
    # https://github.com/delulu/kubernetes/blob/524de768bb64b7adff76792ca3bf0f0ece1e849f/pkg/proxy/winkernel/proxier.go#L532
    Get-HnsPolicyList | Remove-HnsPolicyList

    Write-Host "Cleaning up old HNS network found"
    Remove-HnsNetwork $hnsNetwork
    Start-Sleep 10
}


if ($global:NetworkPlugin -eq "azure") {
    Write-Host "NetworkPlugin azure, starting kubelet."

    Write-Host "Cleaning stale CNI data"
    # Kill all cni instances & stale data left by cni
    # Cleanup all files related to cni
    taskkill /IM azure-vnet.exe /f
    taskkill /IM azure-vnet-ipam.exe /f

    # azure-cni logs currently end up in c:\windows\system32 when machines are configured with containerd.
    # https://github.com/containerd/containerd/issues/4928
    $filesToRemove = @(
        "c:\k\azure-vnet.json",
        "c:\k\azure-vnet.json.lock",
        "c:\k\azure-vnet-ipam.json",
        "c:\k\azure-vnet-ipam.json.lock"
        "c:\k\azure-vnet-ipamv6.json",
        "c:\k\azure-vnet-ipamv6.json.lock"
        "c:\windows\system32\azure-vnet.json",
        "c:\windows\system32\azure-vnet.json.lock",
        "c:\windows\system32\azure-vnet-ipam.json",
        "c:\windows\system32\azure-vnet-ipam.json.lock"
        "c:\windows\system32\azure-vnet-ipamv6.json",
        "c:\windows\system32\azure-vnet-ipamv6.json.lock"
    )

    foreach ($file in $filesToRemove) {
        if (Test-Path $file) {
            Write-Host "Deleting stale file at $file"
            Remove-Item $file
        }
    }
}
# SIG # Begin signature block
# MIInwgYJKoZIhvcNAQcCoIInszCCJ68CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCducgwSvP1xbAF
# HPLO4qMRuDBuWDkKhE5ArGijZZ1yEqCCDZYwggYUMIID/KADAgECAhMzAAAC8wlu
# RQfXwCSWAAAAAALzMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNjMwMTczODIyWhcNMjMwOTE1MTczODIyWjCBiDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWlj
# cm9zb2Z0IDNyZCBQYXJ0eSBBcHBsaWNhdGlvbiBDb21wb25lbnQwggEiMA0GCSqG
# SIb3DQEBAQUAA4IBDwAwggEKAoIBAQCvrQmB9lUe3LFSMM9FTJgENkeA6ehq7Ywo
# CbAga/IYYTpKOyDPJkY9lJOzTPHaIq0XIz4wwAZpM+ECf5Lxb4s79ue7Q+Fg1N/H
# TeAwEDOrSq9jbJTfKxd8f4Lnep+9b91TNh1PvXSpdRVAju+k5VTt75ooadqooEPJ
# /xnS6r1wdcdpeTvh6byyOoNSSbZ4MlBlaJzkM0SeTDw4GNB60KQu1ZUe18H4nRPI
# l7hsoNzBoHqMjbOJbFIf/cdIWlMidscq0Ze6JtCgl8D6Y8tigVEYk3x/ulPfSDm2
# 4s1QrhBSyx6dlOd5AD+mexUWZ+ghqADDDFGGuQY+1WQ7CoKrF33XAgMBAAGjggF+
# MIIBejAfBgNVHSUEGDAWBgorBgEEAYI3TBEBBggrBgEFBQcDAzAdBgNVHQ4EFgQU
# enNHb1tirNTTqab7EgNbT9ptw+AwUAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzE1MjIr
# NDcxMzM2MB8GA1UdIwQYMBaAFEhuZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRN
# MEswSaBHoEWGQ2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01p
# Y0NvZFNpZ1BDQTIwMTFfMjAxMS0wNy0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEG
# CCsGAQUFBzAChkVodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRz
# L01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADAN
# BgkqhkiG9w0BAQsFAAOCAgEAgIkmgihpTZGRMo1zyVuwhFlLzWEDBPxevB+sjcgH
# tISRCEBxwcBKS6WPYPkJCd+cDo3bEMdfCPgyMfBMxQ2DlXaSnRGc5wPVC6hazl55
# S4c6AxacmukRbVe89sb+pbrjxaYJe5Umr4tc9+7ad/e28yirdprT/38KRKXeVwjV
# ZRAUrqyf9SRpOhtD2rcNZRciL82Ib9db3bzzoaG9y0kCaQ+OljehQ8ZOO4Quv8Ze
# 3JGet7zn0KLmXkXSbgaNRiZLneQdB6vL2GW3LrCyVad0Aph9c4SyvlW0FuaMUCRQ
# UL7UcVVT6gUJIIyHHKJ1XGcgdbmAFxA9lDrgogbmc6TUzBUfAWGsgeoAzNTJZ7aO
# Zzg0Y3Y21hsBKAp1Gxz0oys3GB5s7t6msK72zzRsLZF75t8ktuokrkd8C5IS2p/6
# hF0LtPl3aWP0k1V+CYPZw0CgHHVeX5fC/1V353HR8o/T106F636/G4YvMpqm3JTo
# AFAuaGhU5aepW83ZRRjCnZkzUCYCOiDcoDdjcrr6Iu2h54Owqb44JNUnlmCeXNyf
# aPCfpvI9G3PgHg3SyXI67A532uhlNTWXnVaubMjuaKaAlReGQTxeXAOcuzQ71PQX
# cv87lHPdgGJAXxymnSaBWVVXp86Y20fRedFskTYV4YwcRsNk4HwwqdnHy/JWhhn7
# SJUwggd6MIIFYqADAgECAgphDpDSAAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNy
# b3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgy
# MDU5MDlaFw0yNjA3MDgyMTA5MDlaMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENB
# IDIwMTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhu
# qoIQTTS68rZYIZ9CGypr6VpQqrgGOBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEU
# MULTiQ15ZId+lGAkbK+eSZzpaF7S35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugy
# UiYSL+erCFDPs0S3XdjELgN1q2jzy23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4
# 494HDdVceaVJKecNvqATd76UPe/74ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7
# hhvZPrGMXeiJT4Qa8qEvWeSQOy2uM1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1
# JcM5bmR/U7qcD60ZI4TL9LoDho33X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbP
# fLGSrhwjp6lm7GEfauEoSZ1fiOIlXdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez
# +ADhvKwCgl/bwBWzvRvUVUvnOaEP6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX
# 24ON7E1JMKerjt/sW5+v/N2wZuLBl4F77dbtS+dJKacTKKanfWeA5opieF+yL4TX
# V5xcv3coKPHtbcMojyyPQDdPweGFRInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8z
# hNqwiBfenk70lrC8RqBsmNLg1oiMCwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUB
# BAMCAQAwHQYDVR0OBBYEFEhuZOVQBdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcU
# AgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8G
# A1UdIwQYMBaAFHItOgIxkEO5FAVO4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuG
# SWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jv
# b0NlckF1dDIwMTFfMjAxMV8wM18yMi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsG
# AQUFBzAChkJodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dDIwMTFfMjAxMV8wM18yMi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYB
# BAGCNy4DMIGDMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL2RvY3MvcHJpbWFyeWNwcy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABl
# AGcAYQBsAF8AcABvAGwAaQBjAHkAXwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJ
# KoZIhvcNAQELBQADggIBAGfyhqWY4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFl
# Xy4sPvjDctFtg/6+P+gKyju/R6mj82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzz
# PEKLUtCw/WvjPgcuKZvmPRul1LUdd5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirC
# ihC7pKkFDJvtaPpoLpWgKj8qa1hJYx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7l
# ryft0N3zDq+ZKJeYTQ49C/IIidYfwzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhR
# RVg4MnEnGn+x9Cf43iw6IGmYslmJaG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGP
# fxxvFX1Fp3blQCplo8NdUmKGwx1jNpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+
# BncG0QaxdR8UvmFhtfDcxhsEvt9Bxw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQ
# mYAf0AApxbGbpT9Fdx41xtKiop96eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3
# mXkYS//WsyNodeav+vyL6wuA6mk7r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEy
# IXrvQQqxP/uozKRdwaGIm1dxVk5IRcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDN
# MYIZgjCCGX4CAQEwgZUwfjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEoMCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQIT
# MwAAAvMJbkUH18AklgAAAAAC8zANBglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0B
# CQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAv
# BgkqhkiG9w0BCQQxIgQgfZA2WAbrI4lz80tOZgkDbTH5tJxkcP0gIm3UZV28YKkw
# QgYKKwYBBAGCNwIBDDE0MDKgFIASAE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQBvcirBYLHkkIxY
# w0VbHWiXwinDw3PMtAN5Yadcno/+MSBuX/ldmoDZUYbBT3MX0vrCVTN3hHmVks+o
# XFYocNmerOUyWatyOvEw2+dwDcr+xg/PMGbz/fb3GapBNdsyV9VNHRYjk2oceESE
# LsOF0LhtjpEyQgnvCJR+Y7+HfzfTth2J1sN42i9KZPowGI0S5WaUky6nYvxWRNjP
# Lba6aoNE9LLFLy9OCu/bTb1ApINOOVZb2hC5ElydfCx41GhYE67UUtr3mzOvi9qt
# iXSMznfS+nHMCPAWcxJr4/HxIotNIQYHtRgG8pn02Xu387pOTmyUn7Pl32xYk6Oq
# Y02rhBh5oYIXDDCCFwgGCisGAQQBgjcDAwExghb4MIIW9AYJKoZIhvcNAQcCoIIW
# 5TCCFuECAQMxDzANBglghkgBZQMEAgEFADCCAVUGCyqGSIb3DQEJEAEEoIIBRASC
# AUAwggE8AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIMQsys0TQiJZ
# 39LaXIyABjUHv6w17c5rhJWNuWSd84ZOAgZjYskXIKoYEzIwMjIxMTA0MDUzNTI2
# LjM3M1owBIACAfSggdSkgdEwgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBS
# aWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo4OTdBLUUzNTYtMTcwMTElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCEV8wggcQMIIE+KAD
# AgECAhMzAAABqwkJ76tj1OipAAEAAAGrMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIyMDMwMjE4NTEyOFoXDTIzMDUxMTE4
# NTEyOFowgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAn
# BgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQL
# Ex1UaGFsZXMgVFNTIEVTTjo4OTdBLUUzNTYtMTcwMTElMCMGA1UEAxMcTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCC
# AgoCggIBAMmdS1o5dehASUsscLqyx2wm/WirNUfqkGBymDItYzEnoKtkhrd7wNsJ
# s4g+BuM3uBX81WnO270lkrC0e1mmDqQt420Tmb8lwsjQKM6mEaNQIfXDronrVN3a
# w1lx9bAf7VZEA3kHFql6YAO3kjQ6PftA4iVHX3JVv98ntjkbtqzKeJMaNWd8dBaA
# D3RCliMoajTDGbyYNKTvxBhWILyJ8WYdJ/NBDpqPzQl+pxm6ZZVSeBQAIOubZjU0
# vfpECxHC5vI1ErrqapG+0oBhhON+gllVklPAWZv2iv0mgjCTj7YNKX7yL2x2Tvrv
# HVq5GPNa5fNbpy39t5cviiYqMf1RZVZccdr+2vApk5ib5a4O8SiAgPSUwYGoOwbZ
# G1onHij0ATPLkgKUfgaPzFfd5JZSbRl2Xg347/LjWQLR+KjAyACFb06bqWzvHtQJ
# TND8Y0j5Y2SBnSCqV2zNHSVts4+aUfkUhsKS+GAXS3j5XUgYA7SMNog76Nnss5l0
# 1nEX7sHDdYykYhzuQKFrT70XVTZeX25tSBfy3VaczYd1JSI/9wOGqbFU52NyrlsA
# 1qimxOhsuds7Pxo+jO3RjV/kC+AEOoVaXDdminsc3PtlBCVh/sgYno9AUymblSRm
# ee1gwlnlZJ0uiHKI9q2HFgZWM10yPG5gVt0prXnJFi1Wxmmg+BH/AgMBAAGjggE2
# MIIBMjAdBgNVHQ4EFgQUFFvO8o1eNcSCIQZMvqGfdNL+pqowHwYDVR0jBBgwFoAU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIwVGltZS1TdGFt
# cCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBcBggrBgEFBQcw
# AoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNyb3Nv
# ZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIw
# ADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0BAQsFAAOCAgEAykuUgTc1
# KMszMgsHbhgjgEGv/dCHFf0by99C45SR770/udCNNeqlT610Ehz13xGFU6Hci+TL
# UPUnhvUnSuz7xkiWRru5RjZZmSonEVv8npa3z1QveUfngtyi0Jd6qlSykoEVJ6tD
# uR1Kw9xU9yvthZWhQs/ymyOwh+mxt0C9wbeLJ92er2vc9ly12pFxbCNDJ+mQ7v52
# 0hAvreWqZ02GOJhw0R4c1iP39iNBzHOoz+DsO0sYjwhaz9HrvYMEzOD1MJdLPWfU
# FsZ//iTd3jzEykk02WjnZNzIe2ENfmQ/KblGXHeSe8JYqimTFxl5keMfLUELjAh0
# mhQ1vLCJZ20BwC4O57Eg7yO/YuBno+4RrV0CD2gp4BO10KFW2SQ/MhvRWK7HbgS6
# Bzt70rkIeSUto7pRkHMqrnhubITcXddky6GtZsmwM3hvqXuStMeU1W5NN3HA8ypj
# PLd/bomfGx96Huw8OrftcQvk7thdNu4JhAyKUXUP7dKMCJfrOdplg0j1tE0aiE+p
# DTSQVmPzGezCL42slyPJVXpu4xxE0hpACr2ua0LHv/LB6RV5C4CO4Ms/pfal//F3
# O+hJZe5ixevzKNkXXbxPOa1R+SIrW/rHZM6RIDLTJxTGFDM1hQDyafGu9S/a7umk
# vilgBHNxZfk0IYE7RRWJcG7oiY+FGdx1cs0wggdxMIIFWaADAgECAhMzAAAAFcXn
# a54Cm0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0
# aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAx
# ODMyMjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9Kp
# bE51yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cy
# wBAY6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6
# xKr9cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bs
# hVZN7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZht
# aDuaRr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tn
# YN74kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+Autuqfjbs
# Nkz2K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNO
# wTM5TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28M
# yTZki1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsl
# uq9QBXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3
# PmriLq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGC
# NxUCBBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP0
# 5dJlpxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUF
# BwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3Np
# dG9yeS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBT
# AHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgw
# FoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0
# XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAx
# MC0wNi0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5y
# S/ypb+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi
# 7ulmZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2Rje
# bYIM9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n
# 4ECWOKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/
# LAl4FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Q
# q3UwxTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk
# 2XPXfx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBM
# drVXVAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/
# AsGConsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdC
# PSWU5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQ
# wXEGahC0HVUzWLOhcGbyoYIC0jCCAjsCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo4
# OTdBLUUzNTYtMTcwMTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAW6h6/24WCo7WZz6CEVAeLztcmD6ggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOcOmPowIhgPMjAyMjExMDMyMzQ2MDJaGA8yMDIyMTEwNDIzNDYwMlowdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA5w6Y+gIBADAKAgEAAgIMlAIB/zAHAgEAAgISvjAK
# AgUA5w/qegIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAI7zuGYTRvidvRz9
# t3xJ2sgxfqrJJLme/6g5IZj/cmeSjbh4j051N7JBoX/ZtXPhxSJoRt+JPQmJG+Y1
# 2IYozFbW/Dk8vNmDCj2yrycqhU62UBasbpVnSxZfyUzTLinBZqnnKZqsrsWawhuj
# PoWA/rYg8YuUkt+3W1zqH4BhJs2OMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAGrCQnvq2PU6KkAAQAAAaswDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQgQ8+ajaegUJ8/TGMsloPAS8AJPC0naSSruKQTMkSJCn8wgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCAOHK/6sIVgEVSVD3Arvk6OyQKvRxFHKyraUzbN
# 1/AKVzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# qwkJ76tj1OipAAEAAAGrMCIEIKt9kno7b+X/FERTlmfFJ4YDr9G0rqhVxzENHzo9
# xqr2MA0GCSqGSIb3DQEBCwUABIICAJwpuspFkXccUXOW2+MRYZjRdC7TiABXp8TH
# vFTNcKEnh+QYuxhvosMFdR5Fb3zE95t4ugC4URSxomrtzBiKMOdl30a7Tfcqp6w8
# sjG7isR0VJu9eb1BDlKjefQN6kAXUrdQg5cpYRm1bO8vmBGgj1dqx1Ulaj2ofKjH
# 2nFpIU122Y0WcrUqKxhn35yE1LT+cHY7a694VYFCpPo1zU/NU7J6Owoa3xdIbU4f
# uUvg8Q9gn/7s4cQBc0/lTcvIEzzqEIRsjKzp55ufecktL0ePyEmfwg8nDIN/t5sJ
# KFQiNnG5kbh2Sbgd38R2JBg6XMbOl/K4HL/BtNknyH+zw8mJ4qAFh2cW7cdu1N7d
# A1p7QAMLs+LO5kucxkPM88dGLViZtRjCJDEdZgTD/Pxw0XbvWatbwZ9+05n4xthN
# kCUh12f/0Q0aS6gGJ0GLduFUWnLKvVDlUTqvCTHUiscZ+I93fk8dImJSbVxJIB4Q
# FarF7aq7LBPMWmVX5Xgi13HchffYizyvog1EzwVmHx3CwtpIJFgymov6VU15Dy/v
# FVBBQhWOTq/7iro11KiqiXewCvJsQUJ6hLLiKxYPYIObenYhL/hjG7NabR2dAz4w
# h9UCGORVVBBrFp6QPD9Tfbt8gijjfyp9N2BCnDl0f5L4Mp4H15CJwMPDz8nD/KvV
# 7OzgRl58
# SIG # End signature block
