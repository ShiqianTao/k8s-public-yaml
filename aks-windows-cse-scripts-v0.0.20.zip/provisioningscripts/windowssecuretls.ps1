﻿#***************************************************************************************************************
# It does the following:
#   *   Disable TLS 1.O, TLS 1.1, SSLv2, SSLv3 and enables TLS1.2
#   *   The CipherSuite order is set to the SDL approved version.
#   *   The FIPS MinEncryptionLevel is set to 3.
#   *   RC4 is disabled
#***************************************************************************************************************

#******************* FUNCTION THAT ACTUALLY UPDATES KEYS ***********************
function Set-CryptoSetting {
    param ( 
        $regKeyName, 
        $value, 
        $valuedata, 
        $valuetype      
    ) 

    # Check for existence of registry key, and create if it does not exist 
    If (!(Test-Path -Path $regKeyName)) { 
        New-Item $regKeyName | Out-Null 
    } 

    # Get data of registry value, or null if it does not exist 
    $val = (Get-ItemProperty -Path $regKeyName -Name $value -ErrorAction SilentlyContinue).$value 


    If ($val -eq $null) { 
        # Value does not exist - create and set to desired value 
        New-ItemProperty -Path $regKeyName -Name $value -Value $valuedata -PropertyType $valuetype | Out-Null 
    }
    Else { 
        # Value does exist - if not equal to desired value, change it 
        If ($val -ne $valuedata) { 
            Set-ItemProperty -Path $regKeyName -Name $value -Value $valuedata 
        } 
    } 
}
#***************************************************************************************************************

#******************* FUNCTION THAT DISABLES RC4 ***********************
function DisableRC4 {
    $subkeys = Get-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL" 
    $ciphers = $subkeys.OpenSubKey("Ciphers", $true) 

    Write-Log "----- Checking the status of RC4 -----"

    $RC4 = $false
    if ($ciphers.SubKeyCount -eq 0) { 
        $k1 = $ciphers.CreateSubKey("RC4 128/128") 
        $k1.SetValue("Enabled", 0, [Microsoft.Win32.RegistryValueKind]::DWord) 
        $k2 = $ciphers.CreateSubKey("RC4 64/128") 
        $k2.SetValue("Enabled", 0, [Microsoft.Win32.RegistryValueKind]::DWord) 
        $k3 = $ciphers.CreateSubKey("RC4 56/128") 
        $k3.SetValue("Enabled", 0, [Microsoft.Win32.RegistryValueKind]::DWord) 
        $k4 = $ciphers.CreateSubKey("RC4 40/128") 
        $k4.SetValue("Enabled", 0, [Microsoft.Win32.RegistryValueKind]::DWord) 
        
        Write-Log "RC4 was disabled "
        $RC4 = $true
    } 

    If ($RC4 -ne $true) {
        Write-Log "There was no change for RC4 "
    }
}
#***************************************************************************************************************

#******************* FUNCTION CHECKS FOR PROBLEMATIC FIPS SETTING AND FIXES IT  ***********************
function Test-RegistryValueForFipsSettings {            
    $fipsPath = @( 
        "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp",
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services",
        "HKLM:\System\CurrentControlSet\Control\Terminal Server\DefaultUserConfiguration"
    )
    
    $fipsValue = "MinEncryptionLevel"
    
    foreach ($path in $fipsPath) {
        Write-Log "Checking to see if $($path)\$fipsValue exists"

        $ErrorActionPreference = "stop"
        Try {
            $result = Get-ItemProperty -Path $path | Select-Object -ExpandProperty $fipsValue
            if ($result -eq 4) {
                set-itemproperty -Path $path -Name $fipsValue -value 3
                Write-Log "Regkey $($path)\$fipsValue was changed from value $result to a value of 3"
            }
            else {
                Write-Log "Regkey $($path)\$fipsValue left at value $result"
            }
    
        }
        Catch [System.Management.Automation.ItemNotFoundException] {
            Write-Log "Reg path $path was not found"
        }
        Catch [System.Management.Automation.PSArgumentException] {
            Write-Log "Regkey $($path)\$fipsValue was not found"
        }
        Catch {
            Write-Log "Error of type $($Error[0].Exception.GetType().FullName) trying to get $($path)\$fipsValue"
        }
        Finally {
            $ErrorActionPreference = "Continue"
        }
    }
}
#***************************************************************************************************************

#********************************TLS CipherSuite Settings *******************************************

# CipherSuites for windows OS < 10
function Get-BaseCipherSuitesOlderWindows()
{
    param
    (
        [Parameter(Mandatory=$true, Position=0)][bool] $isExcellenceOrder
    )
    $cipherorder = @()

    if ($isExcellenceOrder -eq $true)
    {
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P384"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P384"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P384"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P256"
    }
    else
    {
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P384"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P384"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P384"
    }

    # Add additional ciphers when EnableOlderTlsVersions flag is set to true
    if ($EnableOlderTlsVersions)
    {
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256"
        $cipherorder += "TLS_RSA_WITH_AES_256_GCM_SHA384" 
        $cipherorder += "TLS_RSA_WITH_AES_128_GCM_SHA256" 
        $cipherorder += "TLS_RSA_WITH_AES_256_CBC_SHA256" 
        $cipherorder += "TLS_RSA_WITH_AES_128_CBC_SHA256" 
        $cipherorder += "TLS_RSA_WITH_AES_256_CBC_SHA"
        $cipherorder += "TLS_RSA_WITH_AES_128_CBC_SHA"
    }
    return $cipherorder
}

# Ciphersuites needed for backwards compatibility with Firefox, Chrome
# Server 2012 R2 doesn't support TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384
# Both firefox and chrome negotiate ECDHE_RSA_AES_256_CBC_SHA1, Edge negotiates ECDHE_RSA_AES_256_CBC_SHA384
function Get-BrowserCompatCipherSuitesOlderWindows()
{
    param
    (
        [Parameter(Mandatory=$true, Position=0)][bool] $isExcellenceOrder
    )
    $cipherorder = @()

    if ($isExcellenceOrder -eq $true)
    {
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P384"  # (uses SHA-1)  
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256"  # (uses SHA-1)
    }
    else
    {
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256"  # (uses SHA-1)
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P384"  # (uses SHA-1)  
    }
    return $cipherorder
}

# Ciphersuites for OS versions windows 10 and above
function Get-BaseCipherSuitesWin10Above()
{
    param
    (
        [Parameter(Mandatory=$true, Position=0)][bool] $isExcellenceOrder
    )

    $cipherorder = @()
    if ($isExcellenceOrder -eq $true)
    {
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"
    }
    else
    {
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384"
    }
    # Add additional ciphers when EnableOlderTlsVersions flag is set to true
    if ($EnableOlderTlsVersions)
    {
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P256"
        $cipherorder += "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P256"
        $cipherorder += "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256"
        $cipherorder += "TLS_RSA_WITH_AES_256_GCM_SHA384" 
        $cipherorder += "TLS_RSA_WITH_AES_128_GCM_SHA256" 
        $cipherorder += "TLS_RSA_WITH_AES_256_CBC_SHA256" 
        $cipherorder += "TLS_RSA_WITH_AES_128_CBC_SHA256" 
        $cipherorder += "TLS_RSA_WITH_AES_256_CBC_SHA"
        $cipherorder += "TLS_RSA_WITH_AES_128_CBC_SHA"
    }

    return $cipherorder
}

#******************************* TLS Version Settings ****************************************************

function Get-RegKeyPathForTls12()
{
    $regKeyPath = @(
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2",        
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client", 
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server" 
    )
    return $regKeyPath
}

function Get-RegKeyPathForTls11()
{
    $regKeyPath = @(
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1", 
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client",
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server" 
    )
    return $regKeyPath
}

function Get-RegKeypathForTls10()
{
    $regKeyPath = @(
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0", 
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client", 
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server"
    )
    return $regKeyPath
}

function Get-RegKeyPathForSsl30()
{
    $regKeyPath = @(
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0",        
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client", 
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server"
    )
    return $regKeyPath
}

function Get-RegKeyPathForSsl20()
{
    $regKeyPath = @(
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0",
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client",  
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server"
    )
    return $regKeyPath
}

#******************************* Wrap TLSSettings.ps1 to a function without restart **********************

function Enable-SecureTls {
    $registryPathGoodGuys = @()
    $registryPathBadGuys = @()

    Write-Log -Message "========== Start of logging for Enable-SecureTls =========="
    # we enable TLS 1.2 and disable others
    $registryPathGoodGuys += Get-RegKeyPathForTls12

    $registryPathBadGuys += Get-RegKeyPathForSsl20
    $registryPathBadGuys += Get-RegKeyPathForSsl30
    $registryPathBadGuys += Get-RegKeypathForTls10
    $registryPathBadGuys += Get-RegKeyPathForTls11
    Write-Log "Enabling TLS1.2. Disabling TLS1.1, TLS1.0, SSL3.0, SSL2.0"

    Write-Log "Check which registry keys exist already and which registry keys need to be created." 

    #******************* CREATE THE REGISTRY KEYS IF THEY DON'T EXIST********************************
    # Check for existence of GoodGuy registry keys, and create if they do not exist 
    For ($i = 0; $i -lt $registryPathGoodGuys.Length; $i = $i + 1) { 
        Write-Log "Checking for existing of key: $($registryPathGoodGuys[$i]) "
        If (!(Test-Path -Path $registryPathGoodGuys[$i])) { 
            New-Item $registryPathGoodGuys[$i] | Out-Null
            Write-Log "Creating key: $($registryPathGoodGuys[$i]) "
        }
    } 
    
    # Check for existence of BadGuy registry keys, and create if they do not exist 
    For ($i = 0; $i -lt $registryPathBadGuys.Length; $i = $i + 1) { 
        Write-Log "Checking for existing of key: $($registryPathBadGuys[$i]) "
        If (!(Test-Path -Path $registryPathBadGuys[$i])) { 
            Write-Log "Creating key: $($registryPathBadGuys[$i]) "
            New-Item  $registryPathBadGuys[$i] | Out-Null
        }
    }

    #******************* EXPLICITLY DISABLE SSLV2, SSLV3, TLS10 AND TLS11 ********************************
    For ($i = 0; $i -lt $registryPathBadGuys.Length; $i = $i + 1) {
        if ($registryPathBadGuys[$i].Contains("Client") -Or $registryPathBadGuys[$i].Contains("Server")) {
            Write-Log "Disabling this key: $($registryPathBadGuys[$i]) "
            Set-CryptoSetting $registryPathBadGuys[$i].ToString() Enabled 0 DWord  
            Set-CryptoSetting $registryPathBadGuys[$i].ToString() DisabledByDefault 1 DWord  
        }
    }

    #********************************* EXPLICITLY Enable TLS12 ****************************************
    For ($i = 0; $i -lt $registryPathGoodGuys.Length; $i = $i + 1) {
        if ($registryPathGoodGuys[$i].Contains("Client") -Or $registryPathGoodGuys[$i].Contains("Server")) {
            Write-Log "Enabling this key: $($registryPathGoodGuys[$i]) " 
            Set-CryptoSetting $registryPathGoodGuys[$i].ToString() Enabled 1 DWord  
            Set-CryptoSetting $registryPathGoodGuys[$i].ToString() DisabledByDefault 0 DWord 
        }
    }

    #************************************** Disable RC4 ************************************************
    DisableRC4
        
    #************************************** Set Cipher Suite Order **************************************
    Write-Log "----- starting ciphersuite order calculation for excellence cipher suite order -----" 
    $cipherlist = @()

    if ([Environment]::OSVersion.Version.Major -lt 10) 
    {
        $cipherlist += Get-BaseCipherSuitesOlderWindows -isExcellenceOrder $true
        $cipherlist += Get-BrowserCompatCipherSuitesOlderWindows -isExcellenceOrder $true
    }
    else
    {
        $cipherlist += Get-BaseCipherSuitesWin10Above -isExcellenceOrder $true
    }
    $cipherorder = [System.String]::Join(",", $cipherlist)
    Write-Log "Appropriate ciphersuite order : $cipherorder"
    
    $CipherSuiteRegKey = "HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002" 
    
    if (!(Test-Path -Path $CipherSuiteRegKey)) 
    { 
        New-Item $CipherSuiteRegKey | Out-Null 
        Write-Log "Creating key: $($CipherSuiteRegKey) "
    } 
    
    $val = (Get-Item -Path $CipherSuiteRegKey -ErrorAction SilentlyContinue).GetValue("Functions", $null)
    Write-Log "Previous cipher suite value: $val  "
    Write-Log "New cipher suite value     : $cipherorder  "		 
        
    if ($val -ne $cipherorder) 
    { 
        Write-Log "Cipher suite order needs to be updated. "
        Set-ItemProperty -Path $CipherSuiteRegKey -Name Functions -Value $cipherorder 
        Write-Log "Cipher suite value was updated. "
    }
    else
    {
        Write-Log "Cipher suite order does not need to be updated. "
        Write-Log "Cipher suite value was not updated as there was no change. "
    }
            
    #****************************** CHECK THE FIPS SETTING WHICH IMPACTS RDP'S ALLOWED CIPHERS **************************
    #Check for FipsSettings
    Write-Log "Checking to see if reg keys exist and if MinEncryptionLevel is set to 4"
    Test-RegistryValueForFipsSettings

    Write-Log -Message "========== End of logging for Enable-SecureTls =========="
}
# SIG # Begin signature block
# MIInwQYJKoZIhvcNAQcCoIInsjCCJ64CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC4Cg6bwG/kK8UL
# itAPozfwsX0+Un/Nahpl3yHditLdbKCCDZYwggYUMIID/KADAgECAhMzAAAC8wlu
# RQfXwCSWAAAAAALzMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNjMwMTczODIyWhcNMjMwOTE1MTczODIyWjCBiDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWlj
# cm9zb2Z0IDNyZCBQYXJ0eSBBcHBsaWNhdGlvbiBDb21wb25lbnQwggEiMA0GCSqG
# SIb3DQEBAQUAA4IBDwAwggEKAoIBAQCvrQmB9lUe3LFSMM9FTJgENkeA6ehq7Ywo
# CbAga/IYYTpKOyDPJkY9lJOzTPHaIq0XIz4wwAZpM+ECf5Lxb4s79ue7Q+Fg1N/H
# TeAwEDOrSq9jbJTfKxd8f4Lnep+9b91TNh1PvXSpdRVAju+k5VTt75ooadqooEPJ
# /xnS6r1wdcdpeTvh6byyOoNSSbZ4MlBlaJzkM0SeTDw4GNB60KQu1ZUe18H4nRPI
# l7hsoNzBoHqMjbOJbFIf/cdIWlMidscq0Ze6JtCgl8D6Y8tigVEYk3x/ulPfSDm2
# 4s1QrhBSyx6dlOd5AD+mexUWZ+ghqADDDFGGuQY+1WQ7CoKrF33XAgMBAAGjggF+
# MIIBejAfBgNVHSUEGDAWBgorBgEEAYI3TBEBBggrBgEFBQcDAzAdBgNVHQ4EFgQU
# enNHb1tirNTTqab7EgNbT9ptw+AwUAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzE1MjIr
# NDcxMzM2MB8GA1UdIwQYMBaAFEhuZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRN
# MEswSaBHoEWGQ2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01p
# Y0NvZFNpZ1BDQTIwMTFfMjAxMS0wNy0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEG
# CCsGAQUFBzAChkVodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRz
# L01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADAN
# BgkqhkiG9w0BAQsFAAOCAgEAgIkmgihpTZGRMo1zyVuwhFlLzWEDBPxevB+sjcgH
# tISRCEBxwcBKS6WPYPkJCd+cDo3bEMdfCPgyMfBMxQ2DlXaSnRGc5wPVC6hazl55
# S4c6AxacmukRbVe89sb+pbrjxaYJe5Umr4tc9+7ad/e28yirdprT/38KRKXeVwjV
# ZRAUrqyf9SRpOhtD2rcNZRciL82Ib9db3bzzoaG9y0kCaQ+OljehQ8ZOO4Quv8Ze
# 3JGet7zn0KLmXkXSbgaNRiZLneQdB6vL2GW3LrCyVad0Aph9c4SyvlW0FuaMUCRQ
# UL7UcVVT6gUJIIyHHKJ1XGcgdbmAFxA9lDrgogbmc6TUzBUfAWGsgeoAzNTJZ7aO
# Zzg0Y3Y21hsBKAp1Gxz0oys3GB5s7t6msK72zzRsLZF75t8ktuokrkd8C5IS2p/6
# hF0LtPl3aWP0k1V+CYPZw0CgHHVeX5fC/1V353HR8o/T106F636/G4YvMpqm3JTo
# AFAuaGhU5aepW83ZRRjCnZkzUCYCOiDcoDdjcrr6Iu2h54Owqb44JNUnlmCeXNyf
# aPCfpvI9G3PgHg3SyXI67A532uhlNTWXnVaubMjuaKaAlReGQTxeXAOcuzQ71PQX
# cv87lHPdgGJAXxymnSaBWVVXp86Y20fRedFskTYV4YwcRsNk4HwwqdnHy/JWhhn7
# SJUwggd6MIIFYqADAgECAgphDpDSAAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNy
# b3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgy
# MDU5MDlaFw0yNjA3MDgyMTA5MDlaMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENB
# IDIwMTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhu
# qoIQTTS68rZYIZ9CGypr6VpQqrgGOBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEU
# MULTiQ15ZId+lGAkbK+eSZzpaF7S35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugy
# UiYSL+erCFDPs0S3XdjELgN1q2jzy23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4
# 494HDdVceaVJKecNvqATd76UPe/74ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7
# hhvZPrGMXeiJT4Qa8qEvWeSQOy2uM1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1
# JcM5bmR/U7qcD60ZI4TL9LoDho33X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbP
# fLGSrhwjp6lm7GEfauEoSZ1fiOIlXdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez
# +ADhvKwCgl/bwBWzvRvUVUvnOaEP6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX
# 24ON7E1JMKerjt/sW5+v/N2wZuLBl4F77dbtS+dJKacTKKanfWeA5opieF+yL4TX
# V5xcv3coKPHtbcMojyyPQDdPweGFRInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8z
# hNqwiBfenk70lrC8RqBsmNLg1oiMCwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUB
# BAMCAQAwHQYDVR0OBBYEFEhuZOVQBdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcU
# AgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8G
# A1UdIwQYMBaAFHItOgIxkEO5FAVO4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuG
# SWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jv
# b0NlckF1dDIwMTFfMjAxMV8wM18yMi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsG
# AQUFBzAChkJodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dDIwMTFfMjAxMV8wM18yMi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYB
# BAGCNy4DMIGDMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL2RvY3MvcHJpbWFyeWNwcy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABl
# AGcAYQBsAF8AcABvAGwAaQBjAHkAXwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJ
# KoZIhvcNAQELBQADggIBAGfyhqWY4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFl
# Xy4sPvjDctFtg/6+P+gKyju/R6mj82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzz
# PEKLUtCw/WvjPgcuKZvmPRul1LUdd5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirC
# ihC7pKkFDJvtaPpoLpWgKj8qa1hJYx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7l
# ryft0N3zDq+ZKJeYTQ49C/IIidYfwzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhR
# RVg4MnEnGn+x9Cf43iw6IGmYslmJaG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGP
# fxxvFX1Fp3blQCplo8NdUmKGwx1jNpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+
# BncG0QaxdR8UvmFhtfDcxhsEvt9Bxw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQ
# mYAf0AApxbGbpT9Fdx41xtKiop96eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3
# mXkYS//WsyNodeav+vyL6wuA6mk7r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEy
# IXrvQQqxP/uozKRdwaGIm1dxVk5IRcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDN
# MYIZgTCCGX0CAQEwgZUwfjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEoMCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQIT
# MwAAAvMJbkUH18AklgAAAAAC8zANBglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0B
# CQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAv
# BgkqhkiG9w0BCQQxIgQgj8oSo2FiK+wbkWIcoSTgKbldU1G1atiJbCfph99vFSAw
# QgYKKwYBBAGCNwIBDDE0MDKgFIASAE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQAGHIbubgnE9Cd+
# 0Yy/KxiWcmF/NOEGYpTsqHnk6rtbY4ZRdsDM4SuG0d2YzJy97otmPgl6UJIslGiV
# XJ7s2LDews526mi3m+4fMJxpNSHdZ54c4tgwC/bmit9lLgLWSN4NJx5ZIEn5wXjI
# s4Ks1Qdc511kdictciZLuv04NEkkdbKZ6mHrazK/T0uS951xAdqUnIf+USQ1wOx/
# +HVfj6dfhJrvG1Kgr8US029NlgEHSSAjmxlRigyy4NEIP32NdOUcjVGwzv3Rr8dC
# M5sdhk6LlPRq8Wf5T8kBS12y76ut6wRZCz0LfQYMeIwpg/+t3RvR6wq8ChDirePb
# ID5hcbU2oYIXCzCCFwcGCisGAQQBgjcDAwExghb3MIIW8wYJKoZIhvcNAQcCoIIW
# 5DCCFuACAQMxDzANBglghkgBZQMEAgEFADCCAVQGCyqGSIb3DQEJEAEEoIIBQwSC
# AT8wggE7AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIJc3JlefjlX3
# g1OlhJeEzPEQ9WL1A2AXlM/d6hInYvdeAgZjYr4FbnQYEjIwMjIxMTA0MDUzNTI2
# Ljk2WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJp
# Y28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjc4ODAtRTM5MC04MDE0MSUwIwYD
# VQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIRXzCCBxAwggT4oAMC
# AQICEzMAAAGoVfBhqcwwGFwAAQAAAagwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIwMzAyMTg1MTIzWhcNMjMwNTExMTg1
# MTIzWjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcG
# A1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsT
# HVRoYWxlcyBUU1MgRVNOOjc4ODAtRTM5MC04MDE0MSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAo9ptysAuJdfymPJelww3z0pO9yaUCIPDilT4d6NmGJtR6j8dTL4/1XFa
# EJfuiB54o8nrvv4t5V090bmFO8YOBK6jfD4BybNxdnZAIZSBRF4tQpuauvTpsHTG
# G+1nCh6WHG0+SMkWxtMa1K35XsThUKM91ipBn+I3QCtdeaBsR9XILBL6Ha6igGEz
# lRxs+iC2vlWmB3NtQzj+ta6mYVWM8HVqyff7C/toEIryP1BQmuhjjLWmZlJ/RK4Y
# xZjtybZy+tt2bteV2WOpF0db4JAAHgSqI6qC6Z9H5pKmjlPvkobT6ewGSOUZKxTU
# GLXmnis/zylmdKinvcZ6b0ZY7YZEvA/XlgScqxzPGEZj5nw0RrRDAwyJWWSx09Ts
# nmor2DEBCM4nOohInOEjBBa0QuqAmgfCSpPF6beCtjsHsM7NBOdCkpagvQdZH0qo
# i9oLuL1eU+/657z2P17t+YHieHWG6XMQnNfpExT1MckyVs7o6s/c00QolbyOKkKf
# LwfV+69K4V+4Hu374or2DZzY0q7kTNKzWco2q2Xgo7dTPJcta9NEM7gPk9VA51rS
# 2qNL8BahSvEoLlk+WQsT5g+xLkb4T9UKAJqCE/IFmwc0rvAeVJ//bq6EucqnpdEA
# iuiIRiX/nJbSZKGO+cBE+vQYiVKbQqupLAKNHlyRZPWwpoRvzDcCAwEAAaOCATYw
# ggEyMB0GA1UdDgQWBBQ2x9vj4vhS62U2H8zGMaSPSQsi1TAfBgNVHSMEGDAWgBSf
# pxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1w
# JTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAC
# hlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29m
# dCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAA
# MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4ICAQBxO4JLZGqq
# Z/aY+vo5TJ2GZTH6bq+kQ+zNaKglduexFufLracX1hdMq5I1YfVAV/Jz/Y3dhMSn
# iETxi2FgqAMz8dSFRERfdZPAax5i64N5LFZElYKisAcXWTBDMgqCtRzcb65XACYb
# 8QjUQtETEDh+3HQSGt/n1ombs6eCfSVNJKIpR64YD4zLqgKL9XwRPHP55uW9AA1q
# W0mAZ+mm5ZdhPiOKxAoRO+gmMG/nH4EDSgQW7uAZp4wORmOc7m91/od4qd4guz1m
# /AhaSBhCLZl6jNvGCUbljATGiLF6TGtFMNnAyiQhjFeZxyxxDTFeaH4je+juFX1k
# wpNr09rPmd7hxzw53DVP7rbiYHRZpb0cATWGiMHoJt+6d21X+PDGZ0qHXmmUlec3
# XIzs4v3bgeoCImKwdqek4QnhSb1veEVRcTa4Qkv1pi4iCSxVgirU/b2tHhfuXPe4
# QkfoI6SgTr5Rxq43olgWCE30jwlEFYCEdfgZAeWeCx1+1YsuINkzKeWBEJnORgjb
# g31zH4PfrtjByWo1joJm4CDPDLXa5FgVBqxgdgrWGnPJO24j8DYHxwb4czpfWN/Z
# 324BHAfr6EuQ+23f/k0GUtek6XmJnJGUGLuINeRY1reO4Z8sAnchIPI2HvK74fjJ
# BjJGz8xWsKRZQmz0SK8sqw0nYH8iM2tK1jCCB3EwggVZoAMCAQICEzMAAAAVxedr
# ngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRp
# ZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4
# MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3
# DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qls
# TnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLA
# EBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrE
# qv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyF
# Vk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1o
# O5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg
# 3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2
# TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07B
# MzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJ
# NmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6
# r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+
# auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3
# FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl
# 0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUH
# AgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0
# b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRf
# MjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL
# /Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu
# 6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5t
# ggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfg
# QJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8s
# CXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCr
# dTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZ
# c9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2
# tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8C
# wYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9
# JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDB
# cQZqELQdVTNYs6FwZvKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjc4
# ODAtRTM5MC04MDE0MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloiMKAQEwBwYFKw4DAhoDFQBsuvzEn0EHisvhiDnxfUtnmJB3LKCBgzCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA
# 5w6N+TAiGA8yMDIyMTEwMzIyNTkwNVoYDzIwMjIxMTA0MjI1OTA1WjB3MD0GCisG
# AQQBhFkKBAExLzAtMAoCBQDnDo35AgEAMAoCAQACAglJAgH/MAcCAQACAhKpMAoC
# BQDnD995AgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEA
# AgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEATJsXrm3GbMMXcb5j
# UjY0/YQhuxVNN0V8kZ8FneAWoq3ntKnw5/B8YtwzVL4TEZOk5UZ4WoIP872Z2ReA
# n1X4wlp17D3U5LuQsMeem4Arjiw4/a1359gHrvNcBUPWEOkS3lqzH6dLBiR+F5ea
# wN4Y3Ht4TkiPlpPZzF7D6opqnD4xggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMAITMwAAAahV8GGpzDAYXAABAAABqDANBglghkgBZQME
# AgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJ
# BDEiBCAbBycIkdpAgxhOzTt7UchpcdO0yFb3rHflsdiY6BGu7jCB+gYLKoZIhvcN
# AQkQAi8xgeowgecwgeQwgb0EIHT+yx0AywfCc3CF8UFc+UWdG9aEepJf1gtTEEOX
# XGWmMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAGo
# VfBhqcwwGFwAAQAAAagwIgQgFst9nb68KXPYMepWu2FrKgPTkRtzjpnee3nIOgUF
# 0PgwDQYJKoZIhvcNAQELBQAEggIAE369ItoM/1x3R+9PFSx/ZwrShBMNs5jJNluc
# gJEXTxgH2tQVwdHDMdJRHCWzLBMnDnkyy4caMJpiMtdE7QIjgQOdtQxgUnqWXhFi
# S+JSjne1Dztjj7MSR2qY0bqRBnK8T8PN41kt6/mAGR1QVQGbDcGCA2SRL9rnM85k
# 3F7eRN2gHULvMYUMqmKL1y8vOlE+UbPxoONM9Rv9b9e2u3c4VF2NbuzY56UKW4g/
# WVZ67JmQCrJiD6656M3Xf3mbZmqz4vBLBob94SvMwOMxtxPNp28UgZ6n2BOo0Xm5
# P8ptgVqpAtk/TOY2nJ+7hvRjz5t8pcciujWwBY7fRtNxQcHgwxMgzpBFfH9V8SPD
# 8N9P8Im30SaW8H4MkHbJVDiqpNOb0eXGsdGhy55LpzUnFveHGWZFZKeJXJX3Co8c
# //6a814kVd31IxbkjZxfkkNucpbeu5uyBgmEafhJPkbYzXtqcFYifKYGETKPLJSJ
# bqKolpjgQQX6ajc72AEtrhVo67J0xuODoyzED6uTZdPOXJx9antj/9mi9KcTbCX3
# BwjRIP8ThrDFfW3enALqPmauCyr5z/IkuOFg9DuAemom0JBMKVXTSmoV8SAtKUh1
# bO2vG1KnbcU1oA723NCM7Jd4twCp9EqeIDrzkoJ0M7UCEu5/wTGdA7kUVHI3jXXT
# 6P6Fp2o=
# SIG # End signature block
